package org.example;

import java.sql.*;

public class PrestoJDBC {

    public static void main(String[] args) throws Exception {
        //1.加载驱动
        Class.forName("com.facebook.presto.jdbc.PrestoDriver");
        //2.创建链接
        Connection connection = DriverManager.getConnection("jdbc:presto://192.168.88.80:8090/hive/myhive", "test", null);
        //3.statement
        Statement stmt = connection.createStatement();
        //4.执行SQL
        ResultSet rs = stmt.executeQuery("show tables");
        while (rs.next()) {
            System.out.println(rs.getString(1));
        }
        //5.关闭连接
        rs.close();
        connection.close();

        query();
    }

    public static void query() throws SQLException {
        String url = "jdbc:presto://192.168.88.80:8090/hive/myhive";
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, "test", null);
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * from employee limit 10");
            while (rs.next()) {
                System.out.println(rs.getString(1)+"\t"+rs.getString(2));
            }
            rs.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            connection.close();
        }
    }

}
